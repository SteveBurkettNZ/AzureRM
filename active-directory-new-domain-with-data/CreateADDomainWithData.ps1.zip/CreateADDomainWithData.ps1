﻿configuration CreateADDomainWithData
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds        

    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xPSDesiredStateConfiguration

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node $AllNodes.NodeName
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverWrite = $true
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = 'F'
        }

        File SetupFolder {
            Type = 'Directory'
            DestinationPath = 'C:\Setup'
            Ensure = "Present"
        }
        
        1..$ConfigurationData.NonNodeData.LabCount | ForEach-Object {
            File "LabsFolder_$_" 
                {
                Type = 'Directory'
                DestinationPath = "C:\Setup\Lab $_"
                Ensure = "Present"
                DependsOn = "[File]SetupFolder"
            }
        }
        File LogsFolder {
            Type = 'Directory'
            DestinationPath = 'C:\Logs'
            Ensure = "Present"
        }

        xRemoteFile UserCSVFile {
            DestinationPath = 'C:\Setup\o365UserData.csv'
            Uri = 'https://raw.githubusercontent.com/SteveBurkettNZ/AzureRM/master/active-directory-new-domain-with-data/o365UserData.csv'
            DependsOn = "[File]SetupFolder"
        }

        xRemoteFile AzureADConnectMSI {
            DestinationPath = 'C:\Setup\Lab 2\AzureADConnect.msi'
            Uri = 'https://download.microsoft.com/download/B/0/0/B00291D0-5A83-4DE7-86F5-980BC00DE05A/AzureADConnect.msi'
            DependsOn = "[File]LabsFolder_2"
        }

        xRemoteFile MSOnlineMSI {
            DestinationPath = 'C:\Setup\Lab 1\msoidcli_64.msi'
            Uri = 'https://download.microsoft.com/download/5/0/1/5017D39B-8E29-48C8-91A8-8D0E4968E6D4/en/msoidcli_64.msi'
            DependsOn = "[File]LabsFolder_1"
        }

         xRemoteFile AzureADPSMSI {
            DestinationPath = 'C:\Setup\Lab 1\AdministrationConfig-en.msi'
            Uri = 'http://go.microsoft.com/fwlink/p/?linkid=236297'
            DependsOn = "[File]LabsFolder_1"
        }

        # Copy in Lab Manuals and accompanying PowerShell scripts
        1..$ConfigurationData.NonNodeData.LabCount | ForEach-Object {

            xRemoteFile "PS1File_Lab_$_" {
                DestinationPath = "C:\Setup\Lab $_\Day2Lab$_.ps1"
                Uri = "https://raw.githubusercontent.com/SteveBurkettNZ/AzureRM/master/active-directory-new-domain-with-data/Labs/Day2Lab$_.ps1"
                DependsOn = "[File]LabsFolder_$_"
                }
            xRemoteFile "DocxFile_Lab_$_" {
                DestinationPath = "C:\Setup\Lab $_\Day2Lab$_.docx"
                Uri = "https://raw.githubusercontent.com/SteveBurkettNZ/AzureRM/master/active-directory-new-domain-with-data/Labs/Day2Lab$_.docx"
                DependsOn = "[File]LabsFolder_$_"
                }
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
        }  

        # Optional GUI tools
        WindowsFeature ADDSTools
        { 
            Ensure = 'Present' 
            Name = 'RSAT-ADDS' 
        }

        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = 'F:\NTDS'
            LogPath = 'F:\NTDS'
            SysvolPath = 'F:\SYSVOL'
            DependsOn = "[WindowsFeature]ADDSInstall","[xDisk]ADDataDisk"
        }

        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential = $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[xADDomain]FirstDS"
        } 

        xADRecycleBin RecycleBin
        {
           EnterpriseAdministratorCredential = $DomainCreds
           ForestFQDN = $DomainName
           DependsOn = '[xWaitForADDomain]DscForestWait'
        }

        ### OUs ###
        $DomainRoot = "DC=$($DomainName -replace '\.',',DC=')"
        $DependsOn_OU = @()

        $RootOU = $ConfigurationData.NonNodeData.RootOUs
        xADOrganizationalUnit "OU_$($RootOU)"
            {
                Name = $RootOU
                Path = $DomainRoot
                ProtectedFromAccidentalDeletion = $true
                Description = "OU for $RootOU"
                Credential = $DomainCred
                Ensure = 'Present'
                DependsOn = '[xADRecycleBin]RecycleBin'
            }
         ForEach ($ChildOU in $ConfigurationData.NonNodeData.ChildOUs) {
                
                xADOrganizationalUnit "OU_$($RootOU)_$ChildOU"
                {
                    Name = $ChildOU
                    Path = "OU=$RootOU,$DomainRoot"
                    ProtectedFromAccidentalDeletion = $true
                    Credential = $DomainCred
                    Ensure = 'Present'
                    DependsOn = "[xADOrganizationalUnit]OU_$RootOU"
                }
         }
        
          xADOrganizationalUnit "OU_$($RootOU)_Groups_Cloud Security Groups"
                        {
                        Name = "Cloud Security Groups"
                        Path = "OU=Groups,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for Cloud Security Groups"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Groups"
                        } 
                        
          xADOrganizationalUnit "OU_$($RootOU)_Groups_Non-Cloud Security Groups"
                        {
                        Name = "Non-Cloud Security Groups"
                        Path = "OU=Groups,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for Non-Cloud Security Groups"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Groups"
                        } 

         xADOrganizationalUnit "OU_$($RootOU)_Users_Cloud Users"
                        {
                        Name = "Cloud Users"
                        Path = "OU=Users,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for Cloud Users"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Users"

                        } 
                        
          xADOrganizationalUnit "OU_$($RootOU)_Users_Non-Cloud Users"
                        {
                        Name = "Non-Cloud Users"
                        Path = "OU=Users,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for Non-Cloud Users"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Users"
                        }


            xADUser "SVC_AADConnect"
                {
                DomainName = $DomainName
                Ensure = 'Present'
                UserName = 'SVC_AADConnect'
                JobTitle = 'Service Account'
                Description = 'Azure AD Connect Service Account'
                Path = "OU=Service Accounts,OU=$RootOU,$DomainRoot"
                Enabled = $true
                Password = New-Object -TypeName PSCredential -ArgumentList 'JustPassword', (ConvertTo-SecureString -String $User.Password -AsPlainText -Force)
                PasswordNeverExpires = $true
                DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Service Accounts"
                }
            
            # Set extra permissions on Azure AD Connect Sync Account for password sync feature
            # See: https://azure.microsoft.com/en-us/documentation/articles/active-directory-aadconnect-accounts-permissions/#create-the-ad-ds-account
           <# Script SetPerms_SVC_AADConnect {
                SetScript = {
                    $Identity = "AlpineSkiHouse\SVC_AADConnect"
 
                    $RootDSE = [ADSI]"LDAP://RootDSE"
                    $DefaultNamingContext = $RootDse.defaultNamingContext
                    $ConfigurationNamingContext = $RootDse.configurationNamingContext
                    $UserPrincipal = New-Object Security.Principal.NTAccount("$Identity")
 
                    DSACLS "$DefaultNamingContext" /G "$($UserPrincipal):CA;Replicating Directory Changes"
                    DSACLS "$ConfigurationNamingContext" /G "$($UserPrincipal):CA;Replicating Directory Changes"
                    DSACLS "$DefaultNamingContext" /G "$($UserPrincipal):CA;Replicating Directory Changes All"
                    DSACLS "$ConfigurationNamingContext" /G "$($UserPrincipal):CA;Replicating Directory Changes All"
                       }
                TestScript = {$false}
                GetScript = {
                        #Do Nothing
                        }
                DependsOn = "[xADUSer]SVC_AADConnect"
                        }#>


#Import Cloud Users from file 
        
            Script ImportUsers {
                SetScript = {
                     $path = "OU=Cloud Users,OU=Users,OU=AlpineSkiHouse,DC=alpineskihouse,DC=com"
                     Import-Csv "C:\Setup\o365UserData.csv" | foreach-object {
                     New-ADUser -Name $_.DisplayName -UserPrincipalName $_.UserPrincipalName -SamAccountName $_.Username -GivenName $_.GivenName -DisplayName $_.DisplayName -Initials $_.MiddleInitial -SurName $_.Surname -Description $_.Description -Department $_.Department -EmailAddress $_.EmailAddress -StreetAddress $_.StreetAddress -City $_.City -State $_.State -Country $_.Country -PostalCode $_.ZipCode -OfficePhone $_.PhoneNumber -Title $_.Title -Office $_.Office -AccountPassword (ConvertTo-SecureString $_.Password -AsPlainText -force) -Enabled $True -PasswordNeverExpires $True -PassThru -Path $path }
                     }
                TestScript = {$false}
                GetScript = {
                        #Do Nothing
                        }
                DependsOn = "[xRemoteFile]UserCSVFile","[xADOrganizationalUnit]OU_$($RootOU)_Users_Cloud Users"
                        }
                

        ### GROUPS ###

            xADGroup "NewADGroup_EMS"
            {
                GroupName = "EMS Enabled Users"
                GroupScope = 'Global'
                Description = "Global group for EMS Enabled Users"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }

            xADGroup "NewADGroup_MAM"
            {
                GroupName = "MAM Users"
                GroupScope = 'Global'
                Description = "Global group for Mobile Application Management Users"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            xADGroup "NewADGroup_ExchangeOnline"
            {
                GroupName = "Exchange Online Users"
                GroupScope = 'Global'
                Description = "Global group for Exchange Online Users"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            
            xADGroup "NewADGroup_SharePointOnline"
            {
                GroupName = "SharePoint Online Users"
                GroupScope = 'Global'
                Description = "Global group for SharePoint Online Users"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            xADGroup "NewADGroup_SW_Twitter_Install"
            {
                GroupName = "SW_Twitter_Install"
                GroupScope = 'Global'
                Description = "Global group for Twitter Install"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            xADGroup "NewADGroup_SW_Twitter_Uninstall"
            {
                GroupName = "SW_Twitter_Uninstall"
                GroupScope = 'Global'
                Description = "Global group for Twitter Uninstall"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            xADGroup "NewADGroup_SW_Office_Install"
            {
                GroupName = "SW_Office_Install"
                GroupScope = 'Global'
                Description = "Global group for Office Install"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            xADGroup "NewADGroup_SW_Office_Uninstall"
            {
                GroupName = "SW_Office_Uninstall"
                GroupScope = 'Global'
                Description = "Global group for Office Uninstall"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
             xADGroup "NewADGroup_SW_Managed_Viewers_Install"
            {
                GroupName = "SW_Managed_Viewers_Install"
                GroupScope = 'Global'
                Description = "Global group for Managed Viewers Install"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            xADGroup "NewADGroup_SW_Managed_Viewers_Uninstall"
            {
                GroupName = "SW_Managed_Viewers_Uninstall"
                GroupScope = 'Global'
                Description = "Global group for Managed Viewers Uninstall"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            xADGroup "NewADGroup_AdobeReader_Install"
            {
                GroupName = "SW_Adobe_Reader_Install"
                GroupScope = 'Global'
                Description = "Global group for Adobe Reader Install"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
            xADGroup "NewADGroup_AdobeReader_Uninstall"
            {
                GroupName = "SW_Adobe_Reader_Uninstall"
                GroupScope = 'Global'
                Description = "Global group for Adobe Reader Uninstall"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Security Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Security Groups"
            }
     }
}
