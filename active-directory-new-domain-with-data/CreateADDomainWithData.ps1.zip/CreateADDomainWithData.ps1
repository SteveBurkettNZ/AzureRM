﻿configuration CreateADDomainWithData
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds        

    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xPSDesiredStateConfiguration

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node $AllNodes.NodeName
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverWrite = $true
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = 'F'
        }

        File SetupFolder {
            Type = 'Directory'
            DestinationPath = 'C:\Setup'
            Ensure = "Present"
        }
        
        1..$ConfigurationData.NonNodeData.LabCount | ForEach-Object {
            File "LabsFolder_$_" 
                {
                Type = 'Directory'
                DestinationPath = "C:\Setup\Lab $_"
                Ensure = "Present"
                DependsOn = "[File]SetupFolder"
            }
        }
        File LogsFolder {
            Type = 'Directory'
            DestinationPath = 'C:\Logs'
            Ensure = "Present"
        }

        xRemoteFile UserCSVFile {
            DestinationPath = 'C:\Setup\o365UserData.csv'
            Uri = 'https://raw.githubusercontent.com/SteveBurkettNZ/AzureRM/master/active-directory-new-domain-with-data/o365UserData.csv'
            DependsOn = "[File]SetupFolder"
        }

        xRemoteFile AzureADConnectMSI {
            DestinationPath = 'C:\Setup\AzureADConnect.msi'
            Uri = 'https://download.microsoft.com/download/B/0/0/B00291D0-5A83-4DE7-86F5-980BC00DE05A/AzureADConnect.msi'
        }
        
        xRemoteFile Lab1PSFile {
            DestinationPath = 'C:\Setup\Lab 1\Day2Lab1.ps1'
            Uri = 'https://raw.githubusercontent.com/SteveBurkettNZ/AzureRM/master/active-directory-new-domain-with-data/Labs/Day2Lab1.ps1'
            DependsOn = "[File]LabsFolder_1"
            }
        xRemoteFile Lab1DocxFile {
            DestinationPath = 'C:\Setup\Lab 1\Day2Lab1.docx'
            Uri = 'https://raw.githubusercontent.com/SteveBurkettNZ/AzureRM/master/active-directory-new-domain-with-data/Labs/Day2Lab1.docx'
            DependsOn = "[File]LabsFolder_1"
            }
        WindowsFeature ADDSInstall 
        { 
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
        }  

        # Optional GUI tools
        WindowsFeature ADDSTools
        { 
            Ensure = 'Present' 
            Name = 'RSAT-ADDS' 
        }

        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = 'F:\NTDS'
            LogPath = 'F:\NTDS'
            SysvolPath = 'F:\SYSVOL'
            #DependsOn = "[WindowsFeature]ADDSInstall","[xDnsServerAddress]DnsServerAddress","[cDiskNoRestart]ADDataDisk"
            DependsOn = "[WindowsFeature]ADDSInstall","[xDisk]ADDataDisk"
        }

        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential = $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[xADDomain]FirstDS"
        } 

        xADRecycleBin RecycleBin
        {
           EnterpriseAdministratorCredential = $DomainCreds
           ForestFQDN = $DomainName
           DependsOn = '[xWaitForADDomain]DscForestWait'
        }

        ### OUs ###
        $DomainRoot = "DC=$($DomainName -replace '\.',',DC=')"
        $DependsOn_OU = @()


<#
        ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {

            xADOrganizationalUnit "OU_$RootOU"
            {
                Name = $RootOU
                Path = $DomainRoot
                ProtectedFromAccidentalDeletion = $true
                Description = "OU for $RootOU"
                Credential = $DomainCred
                Ensure = 'Present'
                DependsOn = '[xADRecycleBin]RecycleBin'
            }

            ForEach ($ChildOU in $ConfigurationData.NonNodeData.ChildOUs) {
                
                xADOrganizationalUnit "OU_$($RootOU)_$ChildOU"
                {
                    Name = $ChildOU
                    Path = "OU=$RootOU,$DomainRoot"
                    ProtectedFromAccidentalDeletion = $true
                    Credential = $DomainCred
                    Ensure = 'Present'
                    DependsOn = "[xADOrganizationalUnit]OU_$RootOU"
                }

                $DependsOn_OU += "[xADOrganizationalUnit]OU_$($RootOU)_$ChildOU"

            }
        
        }
#>
        $RootOU = $ConfigurationData.NonNodeData.RootOUs
        xADOrganizationalUnit "OU_$($RootOU)"
            {
                Name = $RootOU
                Path = $DomainRoot
                ProtectedFromAccidentalDeletion = $true
                Description = "OU for $RootOU"
                Credential = $DomainCred
                Ensure = 'Present'
                DependsOn = '[xADRecycleBin]RecycleBin'
            }
         ForEach ($ChildOU in $ConfigurationData.NonNodeData.ChildOUs) {
                
                xADOrganizationalUnit "OU_$($RootOU)_$ChildOU"
                {
                    Name = $ChildOU
                    Path = "OU=$RootOU,$DomainRoot"
                    ProtectedFromAccidentalDeletion = $true
                    Credential = $DomainCred
                    Ensure = 'Present'
                    DependsOn = "[xADOrganizationalUnit]OU_$RootOU"
                }
         }
        
          xADOrganizationalUnit "OU_$($RootOU)_Groups_Cloud Enabled Groups"
                        {
                        Name = "Cloud Enabled Groups"
                        Path = "OU=Groups,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for Cloud Enabled Groups"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Groups"
                        } 
                        
          xADOrganizationalUnit "OU_$($RootOU)_Groups_Non-Cloud Groups"
                        {
                        Name = "Non-Cloud Groups"
                        Path = "OU=Groups,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for Non-Cloud Groups"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Groups"
                        } 

         xADOrganizationalUnit "OU_$($RootOU)_Users_Cloud Users"
                        {
                        Name = "Cloud Users"
                        Path = "OU=Users,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for Cloud Users"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Users"

                        } 
                        
          xADOrganizationalUnit "OU_$($RootOU)_Users_Non-Cloud Users"
                        {
                        Name = "Non-Cloud Users"
                        Path = "OU=Users,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for Non-Cloud Users"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Users"
                        }

<#
         ForEach ($UserOU in $ConfigurationData.NonNodeData.UsersOUs) {

                 xADOrganizationalUnit "OU_$($RootOU)_Users_$UserOU"
                        {
                        Name = $UserOU
                        Path = "OU=Users,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for $UserOU"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Users"
                        }
                }

               # $DependsOn_OU += "[xADOrganizationalUnit]OU_$($RootOU)_Users_$UserOU"
        
          ForEach ($GroupOU in $ConfigurationData.NonNodeData.GroupsOUs) {
                 xADOrganizationalUnit "OU_$($RootOU)_Groups_$GroupOU"
                        {
                        Name = $GroupOU
                        Path = "OU=Groups,OU=$RootOU,$DomainRoot"
                        ProtectedFromAccidentalDeletion = $true
                        Description = "OU for $GroupOU"
                        Credential = $DomainCred
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Groups"
                        }
                }
                # $DependsOn_OU += "[xADOrganizationalUnit]OU_$($RootOU)_Groups_$GroupOU"

#>

#Import Cloud Users from file 

        Script ImportUsers {
                SetScript = {
                     $path = "OU=Cloud Users,OU=Users,OU=AlpineSkiHouse,DC=alpineskihouse,DC=com"
                     Import-Csv "C:\Setup\o365UserData.csv" | foreach-object {
                     New-ADUser -Name $_.DisplayName -UserPrincipalName $_.UserPrincipalName -SamAccountName $_.Username -GivenName $_.GivenName -DisplayName $_.DisplayName -Initials $_.MiddleInitial -SurName $_.Surname -Description $_.Description -Department $_.Department -StreetAddress $_.StreetAddress -City $_.City -State $_.State -Country $_.Country -PostalCode $_.ZipCode -OfficePhone $_.PhoneNumber -Title $_.Title -Office $_.Office -AccountPassword (ConvertTo-SecureString $_.Password -AsPlainText -force) -Enabled $True -PasswordNeverExpires $True -PassThru -Path $path }
                    
                    <#$UserDataCSV = 'C:\setup\o365UserData.csv'
                    $Users = import-csv $UserDataCSV -Encoding UTF8
                    ForEach ($User in $Users) {
                        xADUser "NewADUser_$($User.UserName)"
                           {
                            DomainName = $DomainName
                            Ensure = 'Present'
                            UserName = $User.Firstname + "." + $User.Lastname
                            GivenName = $User.Firstname
                            Surname = $User.LastName
                            City = $User.City
                            JobTitle = $User.Title
                            Path = "OU=Cloud Users,OU=Users,OU=$RootOU,$DomainRoot"
                            Enabled = $true
                            Password = New-Object -TypeName PSCredential -ArgumentList 'JustPassword', (ConvertTo-SecureString -String $User.Password -AsPlainText -Force)
                            DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Users_Cloud Users"
                            }
                        }#>
                    }
                TestScript = {$false}
                GetScript = {
                        #Do Nothing
                        }
                DependsOn = "[xRemoteFile]UserCSVFile","[xADOrganizationalUnit]OU_$($RootOU)_Users_Cloud Users"
                        }
                
<#      
        ### USERS ###
        $DependsOn_User = @()
        $Users = $ConfigurationData.NonNodeData.UserData | ConvertFrom-CSV
        ForEach ($User in $Users) {

            xADUser "NewADUser_$($User.UserName)"
            {
                DomainName = $DomainName
                Ensure = 'Present'
                UserName = $User.UserName
                JobTitle = $User.Title
                Path = "OU=Cloud Users,OU=Users,OU=$RootOU,$DomainRoot"
                Enabled = $true
                Password = New-Object -TypeName PSCredential -ArgumentList 'JustPassword', (ConvertTo-SecureString -String $User.Password -AsPlainText -Force)
                DependsOn = "[xADOrganizationalUnit]OU_$($RootOU)_Users_Cloud Users"
            }
            #$DependsOn_User += "[xADUser]NewADUser_$($User.UserName)"
        }


        1..$ConfigurationData.NonNodeData.TestObjCount | ForEach-Object {

            xADUser "NewADUser_$_"
            {
                DomainName = $DomainName
                Ensure = 'Present'
                UserName = "TestUser$_"
                Enabled = $false  # Must specify $false if disabled and no password
                DependsOn = '[xADRecycleBin]RecycleBin'
            }

        }

#>
        ### GROUPS ###
    #    ForEach ($RootOU in $ConfigurationData.NonNodeData.RootOUs) {
     #       xADGroup "NewADGroup_$RootOU"
      #      {
      #          GroupName = "G_$RootOU"
      #          GroupScope = 'Global'
      #          Description = "Global group for $RootOU"
      #          Category = 'Security'
      #          Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
      #          Path = "OU=Groups,OU=$RootOU,$DomainRoot"
      #          Ensure = 'Present'
      #          DependsOn = $DependsOn_User
      #      }
      #  }


            xADGroup "NewADGroup_EMS"
            {
                GroupName = "EMS Enabled Users"
                GroupScope = 'Global'
                Description = "Global group for EMS Enabled Users"
                Category = 'Security'
                #Members = ($Users | Where-Object {$_.Dept -eq $RootOU}).UserName
                Path = "OU=Cloud Enabled Groups,OU=Groups,OU=$RootOU,$DomainRoot"
                Ensure = 'Present'
                DependsOn = "[xADRecycleBin]RecycleBin","[xADOrganizationalUnit]OU_$($RootOU)_Groups_Cloud Enabled Groups"
            }
<#
        1..$ConfigurationData.NonNodeData.TestObjCount | ForEach-Object {

            xADGroup "NewADGroup_$_"
            {
                GroupName = "TestGroup$_"
                GroupScope = 'Global'
                Category = 'Security'
                Members = "TestUser$_"
                Ensure = 'Present'
                DependsOn = "[xADUser]NewADUser_$_"
            }


        }
#>
   
  }
}
